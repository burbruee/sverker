<?php	
	include("../config.php");
	include("../dbopen.php");
		
	$print = "";
	$result = mysql_query("SELECT * FROM triggers") or die(mysql_error());
	
	while($db_get = mysql_fetch_assoc($result))
	{
		$print .= $db_get["trigger"] . "§" . $db_get["answer"] .  "§" . $db_get["case"] . "§" . $db_get["pos"] . "|";
	}
	
	$print = trim($print,"|");
	echo($print);
	
	include("../dbclose.php");

?>
