<?php
	include("../config.php");
	include("../dbopen.php");
	
	if (isset($_GET["id"]))
	{
		$id = mysql_real_escape_string($_GET["id"]);
		mysql_query("DELETE FROM triggers WHERE id=" . $id) or die(mysql_error());
	}
				
	header("Location: list.php");
	include("../dbclose.php");
	exit;
?>
