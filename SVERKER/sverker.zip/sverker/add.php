<?php
	include("../config.php");
	include("../dbopen.php");	
	
	if (isset($_POST["t"]) && isset($_POST["r"]))
	{
		$t = mysql_real_escape_string($_POST["t"]);
		$r = mysql_real_escape_string($_POST["r"]);
		$case = mysql_real_escape_string($_POST["case"]);
		$pos = mysql_real_escape_string($_POST["pos"]);
		
		$case = (isset($_POST["case"]) ? "yes" : "no");
		$pos = (isset($_POST["pos"]) ? "yes" : "no");

		mysql_query("INSERT INTO `$dbname`.`triggers` (`id` ,`trigger` ,`answer`, `case`, `pos`)VALUES (NULL , '" . $t . "', '" . $r . "', '$case', '$pos');") or die(mysql_error());			
	}
	
	
	
	
		
		
	header("Location: list.php");
	include("../dbclose.php");
	exit;

?>
