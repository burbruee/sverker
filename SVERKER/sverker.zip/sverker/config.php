<?php 
	$dbhost = "";
	$dbuser = "";
	$dbpass = "";
	$dbname = "";
?>
