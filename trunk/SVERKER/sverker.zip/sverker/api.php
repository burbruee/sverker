<?php	
	include("../config.php");
	include("../dbopen.php");
		
	$print = "";
	$result = mysql_query("SELECT * FROM triggers") or die(mysql_error());
	
	while($db_get = mysql_fetch_assoc($result))
	{
		$print .= $db_get["trigger"] . "�" . $db_get["answer"] . "|";
	}
	
	$print = trim($print,"|");
	echo($print);
	
	include("../dbclose.php");

?>
