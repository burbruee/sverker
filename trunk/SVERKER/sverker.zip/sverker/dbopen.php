<?php	
	$db = mysql_connect($dbhost, $dbuser, $dbpass) or trigger_error(mysql_error(),E_USER_ERROR);
	mysql_select_db($dbname,$db);
?>
