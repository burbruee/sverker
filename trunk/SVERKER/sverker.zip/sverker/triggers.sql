-- phpMyAdmin SQL Dump
-- version 2.11.3deb1ubuntu1.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 04, 2010 at 07:25 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.4-2ubuntu5.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `105628-sverker`
--

-- --------------------------------------------------------

--
-- Table structure for table `triggers`
--

CREATE TABLE IF NOT EXISTS `triggers` (
  `id` int(11) NOT NULL auto_increment,
  `trigger` varchar(255) NOT NULL,
  `answer` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=37 ;

--
-- Dumping data for table `triggers`
--

INSERT INTO `triggers` (`id`, `trigger`, `answer`) VALUES
(34, 'help', 'Yes $n, it''s about time you get some help...'),
(30, 'hello', 'Hello there, $n! :)'),
(31, 'test', 'What are you testing, $n?'),
(32, 'boo!', 'Stop it $n, you''re scaring me! :('),
(33, 'credits', 'I was created by Fr4sbokz and Burbruee in C++, true story!'),
(36, 'sverker?', 'Yes, $n?');
