<?php
	include("../config.php");
	include("../dbopen.php");
	
	$result = mysql_query("SELECT * FROM triggers") or die(mysql_error());
	
	while($db_get = mysql_fetch_assoc($result))
	{
		$list .= "|" . $db_get["trigger"] . "| - |" . $db_get["answer"] . "| <a href=\"del.php?id=" . $db_get["id"] . "\">Remove</a><br />";
		$table .= "<tr><td>" . $db_get["trigger"] . "</td><td>" . $db_get["answer"] . "</td><td><a href=\"del.php?id=" . $db_get["id"] . "\">Remove</a></td></tr>";
	}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
      <link  href="styleNew.css" rel="stylesheet" type="text/css" />
      <title>SVERKER API -> LIST</title>
</head>

<body>
<div  id="wrapper">
	<h1>Add  new Trigger</h1>
	<div  id="formcontainer">
		<form method="post" action="add.php">
			<div  class="clearfix">
			 	<label>Trigger</label>
			 	<input name="t" type="text" size="25" />
			</div>
			
			<div  class="clearfix">
			 	<label>Response</label>
			 	<input name="r" type="text" size="25" />
			</div>
			
			<div  class="buttonfix">
			 	<input type="submit" value="Add new Trigger" />
			</div>		
		</form>
	</div>
	
	<h1>List Triggers</h1>
	<div  id="api">
		<table border="0" width="640">
		 	<tr>
		 		<td><strong>Trigger</strong></td>
		 		<td><strong>Response</strong></td>
		 		<td><strong>Delete?</strong></td>
	 		</tr>
	 		<?php echo($table); ?>
		</table>		
	</div>
</div>

</body>
</html>	
<?php 
	include("../dbclose.php")
?>
